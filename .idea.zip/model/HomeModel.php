<?php

class HomeModel
{

    /**
     * @param MyConexion $conexion
     */
    public function __construct(\MyConexion $conexion)
    {
    }
}