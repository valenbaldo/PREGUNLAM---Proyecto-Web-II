<?php
class PerfilController
{
    private $model;
    private $renderer;

    public function __construct($model, $renderer) {
        $this->model = $model;
        $this->renderer = $renderer;
    }

    public function base() {
        $nombreUsuario = $_SESSION['nombreUsuario'];
        $idUsuario = $_SESSION['id_usuario'] ?? null;
        if (!$idUsuario) {
            header("Location: /login");
            exit;
        }

        $usuario = $this->model->obtenerPerfil((int)$idUsuario);
        $stats   = $this->model->obtenerStats((int)$idUsuario);

        $this->renderer->render("perfil", [
            'usuario' => $usuario,
            'nombreUsuario' => $nombreUsuario,
            'stats'   => $stats,
        ]);
    }
}
